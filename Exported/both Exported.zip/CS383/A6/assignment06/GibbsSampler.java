package assignment06;



public class GibbsSampler{
	
	public GibbsSampler(){
		
	}
	
	
}