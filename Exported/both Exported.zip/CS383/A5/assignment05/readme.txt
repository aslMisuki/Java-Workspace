Nam Phan

This is the readme for assignment05

What is working
	- Parsing the input (single and multi line)
	- Parsing the car.data file
	- Size is correct so that is good (1728)
	- Single probabilities are good
	- The givenList now collects and filters the correct given data (I think/Hope)
	- create table now works and populates all permutations with elements corresponding to correct attributes

What is sort of working

What is not working