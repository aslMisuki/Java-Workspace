Nam Phan

Optimizations: I used the minimax algorithm in order to compute the minimax value optimiazations

Working: everything except the algorithm

Partially working:
	The utility function is still not working the way I had hoped

Not Working:
	most of the algorithm has been implemented but the utility function