package assignment04;

public class KakuroSolver {

	
	public KakuroSolver(){
		
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
